/*
*Assignment 4: Building a multi-screen App
*
* CityViewModel.kt
*
* Zoe Gerst
* gerstz@oregonstate.edu
* CS 492
* Oregon State University
*
* Wasn't able to get to the details screen
*
* works cited: https://developer.android.com/codelabs/basic-android-kotlin-compose-practice-sports-app?continue=https%3A%2F%2Fdeveloper.android.com%2Fcourses%2Fpathways%2Fandroid-basics-compose-unit-4-pathway-3%23codelab-https%3A%2F%2Fdeveloper.android.com%2Fcodelabs%2Fbasic-android-kotlin-compose-practice-sports-app#0

 */

package com.example.sports.ui

import androidx.lifecycle.ViewModel
import com.example.sports.data.Data
import com.example.sports.model.Sport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class CityViewModel : ViewModel() {


    private val _uiState = MutableStateFlow(
        SportsUiState(
            sportsList = Data.getSportsData(),
            restList = Data.getRestaurantData(),
            tourList = Data.getTouristData(),
            parkList = Data.getParkData(),
            currentSport = Data.getSportsData().getOrElse(0) {
                Data.defaultSport
            } ,
            currentRest = Data.getRestaurantData().getOrElse(0) {
                Data.defaultRest
            },
            currentTour = Data.getTouristData().getOrElse(0) {
                Data.defaultTour
            },
            currentPark = Data.getParkData().getOrElse(0) {
                Data.defaultPark
            }
        )
    )
    val uiState: StateFlow<SportsUiState> = _uiState

    fun updateCurrentSport(selectedSport: Sport) {
        _uiState.update {
            it.copy(currentSport = selectedSport)
        }
    }

    fun updateCurrentRest(selectedRest: Sport) {
        _uiState.update {
            it.copy(currentRest = selectedRest)
        }
    }

    fun updateCurrentTour(selectedTour: Sport) {
        _uiState.update {
            it.copy(currentTour = selectedTour)
        }
    }

    fun updateCurrentPark(selectedPark: Sport) {
        _uiState.update {
            it.copy(currentPark = selectedPark)
        }
    }

    fun navigateToListPage() {
        _uiState.update {
            it.copy(isShowingListPage = true)
        }
    }

    fun navigateToRestPage() {
        _uiState.update {
            it.copy(isShowingRestListPage = false)
        }
    }

    fun navigateToTourPage() {
        _uiState.update {
            it.copy(isShowingTourListPage = false)
        }
    }

    fun navigateToParkPage() {
        _uiState.update {
            it.copy(isShowingParkListPage = false)
        }
    }


    fun navigateToDetailPage() {
        _uiState.update {
            it.copy(isShowingListPage = false)
        }
    }

    fun navigateToRestDetailPage() {
        _uiState.update {
            it.copy(isShowingRestListPage = false)
        }
    }

    fun navigateToTourDetailPage() {
        _uiState.update {
            it.copy(isShowingTourListPage = false)
        }
    }
    fun navigateToParkDetailPage() {
        _uiState.update {
            it.copy(isShowingParkListPage = false)
        }
    }
}

data class SportsUiState(
    val sportsList: List<Sport> = emptyList(),
    val restList: List<Sport> = emptyList(),
    val tourList: List<Sport> = emptyList(),
    val parkList: List<Sport> = emptyList(),
    val currentSport: Sport = Data.defaultSport,
    val currentRest: Sport = Data.defaultRest,
    val currentTour: Sport = Data.defaultTour,
    val currentPark: Sport = Data.defaultPark,
    val isShowingListPage: Boolean = true,
    var isShowingRestListPage: Boolean = false,
    var isShowingTourListPage: Boolean = false,
    var isShowingParkListPage: Boolean = false
)