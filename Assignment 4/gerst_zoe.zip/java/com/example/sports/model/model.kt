/*
*Assignment 4: Building a multi-screen App
*
* model.kt
*
* Zoe Gerst
* gerstz@oregonstate.edu
* CS 492
* Oregon State University
*
* Wasn't able to get to the details screen
*
* works cited: https://developer.android.com/codelabs/basic-android-kotlin-compose-practice-sports-app?continue=https%3A%2F%2Fdeveloper.android.com%2Fcourses%2Fpathways%2Fandroid-basics-compose-unit-4-pathway-3%23codelab-https%3A%2F%2Fdeveloper.android.com%2Fcodelabs%2Fbasic-android-kotlin-compose-practice-sports-app#0

 */
package com.example.sports.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes


data class Sport(
    val id: Int,
    @StringRes val titleResourceId: Int,
    @StringRes val subtitleResourceId: Int,
    @DrawableRes val imageResourceId: Int,
    @StringRes val sportDetails: Int
)
data class Recommend(
    @StringRes val typeOfPlace: Int
)