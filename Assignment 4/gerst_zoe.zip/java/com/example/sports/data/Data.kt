/*
*Assignment 4: Building a multi-screen App
*
* Data.kt
*
* Zoe Gerst
* gerstz@oregonstate.edu
* CS 492
* Oregon State University
*
* Wasn't able to get to the details screen
*
* works cited: https://developer.android.com/codelabs/basic-android-kotlin-compose-practice-sports-app?continue=https%3A%2F%2Fdeveloper.android.com%2Fcourses%2Fpathways%2Fandroid-basics-compose-unit-4-pathway-3%23codelab-https%3A%2F%2Fdeveloper.android.com%2Fcodelabs%2Fbasic-android-kotlin-compose-practice-sports-app#0

 */

package com.example.sports.data

import com.example.sports.R
import com.example.sports.model.Sport

object Data{
    val defaultSport = getSportsData()[0]
    val defaultRest = getRestaurantData()[0]
    val defaultTour = getTouristData()[0]
    val defaultPark = getParkData()[0]

    fun getSportsData(): List<Sport> {
        return listOf(
            Sport(
                id = 1,
                titleResourceId = R.string.restaurant_list,
                subtitleResourceId = R.string.restaurant_sub,
                imageResourceId = R.drawable.burger_restaurant_png_free_image,
                sportDetails = R.string.sport_detail_text

            ),
            Sport(
                id = 2,
                titleResourceId = R.string.tourist_list,
                subtitleResourceId = R.string.tourist_sub,
                imageResourceId = R.drawable.cam,
                sportDetails = R.string.sport_detail_text
            ),
            Sport(
                id = 3,
                titleResourceId = R.string.park_list,
                subtitleResourceId = R.string.park_sub,
                imageResourceId = R.drawable.park,
                sportDetails = R.string.sport_detail_text
            ),

        )
    }
    fun getRestaurantData(): List<Sport> {
        return listOf(
            Sport(
                id = 1,
                titleResourceId = R.string.restaurant_1,
                subtitleResourceId = R.string.restaurant_1_address,
                imageResourceId = R.drawable.south_pasadena_news_06_29_21_mammas_brick_oven_pizza_pasta_business_amp_021,
                sportDetails = R.string.restaurant_1_details

            ),
            Sport(
                id = 2,
                titleResourceId = R.string.restaurant_2,
                subtitleResourceId = R.string.restaurant_2_address,
                imageResourceId = R.drawable.gussbbq,
                sportDetails = R.string.restaurant_2_details
            ),
            Sport(
                id = 3,
                titleResourceId = R.string.restaurant_3,
                subtitleResourceId = R.string.restaurant_3_address,
                imageResourceId = R.drawable.silverramen,
                sportDetails = R.string.restaurant_3_details
            ),
            Sport(
                id = 4,
                titleResourceId = R.string.restaurant_4,
                subtitleResourceId = R.string.restaurant_4_address,
                imageResourceId = R.drawable.hilife,
                sportDetails = R.string.restaurant_4_details
            )

            )
    }
    fun getTouristData(): List<Sport> {
        return listOf(
            Sport(
                id = 1,
                titleResourceId = R.string.tourist_1,
                subtitleResourceId = R.string.tourist_1_address,
                imageResourceId = R.drawable.fop,
                sportDetails = R.string.tourist_1_details

            ),
            Sport(
                id = 2,
                titleResourceId = R.string.tourist_2,
                subtitleResourceId = R.string.tourist_2_address,
                imageResourceId = R.drawable.histsp,
                sportDetails = R.string.tourist_2_details
            ),
            Sport(
                id = 3,
                titleResourceId = R.string.tourist_3,
                subtitleResourceId = R.string.tourist_3_address,
                imageResourceId = R.drawable.wrigely,
                sportDetails = R.string.tourist_3_details
            ),
            Sport(
                id = 4,
                titleResourceId = R.string.tourist_4,
                subtitleResourceId = R.string.tourist_4_address,
                imageResourceId = R.drawable.arlington,
                sportDetails = R.string.tourist_4_details
            )

        )
    }
    fun getParkData(): List<Sport> {
        return listOf(
            Sport(
                id = 1,
                titleResourceId = R.string.park_1,
                subtitleResourceId = R.string.park_1_address,
                imageResourceId = R.drawable.ogpark,
                sportDetails = R.string.park_1_details

            ),
            Sport(
                id = 2,
                titleResourceId = R.string.park_2,
                subtitleResourceId = R.string.park_2_address,
                imageResourceId = R.drawable.garfieldpark,
                sportDetails = R.string.park_2_details
            ),
            Sport(
                id = 3,
                titleResourceId = R.string.park_3,
                subtitleResourceId = R.string.park_3_address,
                imageResourceId = R.drawable.montereyhills_1,
                sportDetails = R.string.park_3_details
            ),
            Sport(
                id = 4,
                titleResourceId = R.string.park_4,
                subtitleResourceId = R.string.park_4_address,
                imageResourceId = R.drawable.arroyo,
                sportDetails = R.string.park_4_details
            )

        )
    }
}
